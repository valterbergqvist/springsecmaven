package com.example.demo.service;

import com.example.demo.model.Ordertest;
import com.example.demo.model.Product;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.ProductRepository;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImp implements OrderService {
    @Autowired
    OrderRepository repo;
    @Autowired
    ProductRepository repo2;



    @Override
    public Product getProductById(int id) {
        return repo2.findById(id).get();
    }



    @Override
    public void saveOrder(Ordertest ordertest) {
        {
            repo.save(ordertest);
        }


    }

    @Override
    public void deleteOrder(int id) {
        this.repo.deleteById(id);
    }


    @Override
    public double findByProductprice(double productprice) {
        return repo.findByProductprice(productprice);
    }

    @Override
    public Ordertest findbyId(int oderId) {
        return repo.findById(oderId).get();
    }
}
