package com.example.demo.repository;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepository extends CrudRepository<User,Long> {
    public List<User> findByEmailAndPassword(String email, String Password);




    @Query("Select u from User u where u.email = :email")
    public User getUserbyemail(@Param("email") String email);



}
