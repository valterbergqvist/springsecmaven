package com.example.demo.service;

import com.example.demo.model.Ordertest;
import com.example.demo.model.Product;

import java.util.List;

public interface OrderService  {


    public Product getProductById(int id);


    public void saveOrder (Ordertest ordertest) ;
    public void deleteOrder(int id);
    public double findByProductprice(double productprice);
    public Ordertest findbyId(int oderId);
}
