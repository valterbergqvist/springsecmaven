package com.example.demo.controller;


import com.example.demo.model.Ordertest;
import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.OrderService;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;

@Controller
@RequestMapping("/products")
public class ProductController {


    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/all")
    public String getAllProducts(Model model) {
       /** productService.saveProducts();*/
        model.addAttribute("products",productService.getAllProducts());

        return "product_all";
    }

    /**
     * Get product by id
     */

  /**  @GetMapping("/{productId}")
    public String getProductById(Model model, @PathVariable("productId") int productId) {

        model.addAttribute("product",productService.getProductById(productId));
        return "product";
    } */


    /**
     *
     * get all orders
     */



    @GetMapping("/{getOrdersId}")
    public String getOrders(Model model, @PathVariable("getOrdersId") int productId ) {
        Ordertest ordertest = new Ordertest();
        Product product = productService.getProductById(productId);
        ordertest.setProductname(product.getName());
        ordertest.setProductprice(product.getPrice());
        orderService.saveOrder(ordertest);
        model.addAttribute("orders",ordertest);
        return "orders";
    }

    /**
     *checlout orders
     */

    @GetMapping("ordertest/{ordertest}")
    public String checkoutorders (Model model, @PathVariable("ordertest") int order ) {

        Ordertest ordertest = orderService.findbyId(order);
        System.out.println(ordertest);
        double price = ordertest.getProductprice();
        model.addAttribute("pricefororder",price);
        model.addAttribute("orderId",ordertest);
        return "checkout";
    }
    @GetMapping("/order/delete/{ordertest}")
    public String deleteEmployee( @PathVariable("ordertest") int order, Model model) {
        orderService.deleteOrder(order);
        return "orders";

    }
}