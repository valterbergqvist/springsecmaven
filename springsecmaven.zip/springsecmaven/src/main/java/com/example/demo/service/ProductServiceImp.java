package com.example.demo.service;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

@Service
public class ProductServiceImp implements ProductService {

@Autowired
ProductRepository repo;

    @Override
    public List<Product> getAllProducts() {

      ArrayList<Product> listOfProducts = (ArrayList<Product>) repo.findAll();

        return listOfProducts;
    }

    @Override
    public Product getProductById(int id) {

     return repo.findById(id).get();

        /** Predicate<Product> byId = p -> p.getId().equals(id);
         *
         *
        return filterProducts(byId);
         */
    }



    public void saveProducts ()  {
        repo.saveAll(getAllProducts());
    }

}