package com.example.demo.configuration;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserDetailsImpl implements UserDetailsService {

    @Autowired
    private UserRepository userrepo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        User user = userrepo.getUserbyemail(email);

        if (user == null) {

            throw new UsernameNotFoundException("User could not be found");

        }

        CustomUserDetails details = new CustomUserDetails(user);

        return details;

    }

}

