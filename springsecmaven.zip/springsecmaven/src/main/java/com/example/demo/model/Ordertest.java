package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ordertest {


    private String productname;

    private double productprice;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    public double getProductprice() {
        return productprice;
    }

    public void setProductprice(double productprice) {
        this.productprice = productprice;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductprice(int productprice) {
        this.productprice = productprice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Ordertest{" +
                "productname='" + productname + '\'' +
                ", productprice=" + productprice +
                ", id=" + id +
                '}';
    }
}
