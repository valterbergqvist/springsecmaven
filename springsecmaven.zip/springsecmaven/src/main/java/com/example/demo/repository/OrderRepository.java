package com.example.demo.repository;

import com.example.demo.model.Ordertest;
import com.example.demo.model.Product;
import org.hibernate.criterion.Order;
import org.springframework.data.repository.CrudRepository;

public interface OrderRepository extends CrudRepository<Ordertest,Integer> {
    public double findByProductprice(double productprice);

}
